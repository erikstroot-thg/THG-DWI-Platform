# Procesbeschrijving – THG Klachtenregistratie
1) Melding → registratie
2) Triagering (status / prioriteit / verantwoordelijke)
3) Analyse: primaire + alternatieve oorzaken; gemiste detectie (CNC/Harding/QA/Expeditie)
4) Traceerbaarheid: A+W (order, station, planstatus), Shiftbase (ploeg), Transport (transporteur/route/laadwijze)
5) Maatregelen: corrigerend / preventief
6) Afhandeling: status Afgehandeld, datum, handtekening
7) Evaluatie & rapportage (Pareto/5xWhy/8D)
